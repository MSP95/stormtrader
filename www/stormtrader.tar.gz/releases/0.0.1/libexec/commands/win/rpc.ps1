## Execute an MFA on the running node via `:rpc`

release-remote-ctl rpc @args
